# -*- coding: utf-8 -*-
"""
Created on Wed Apr 28 11:24:45 2021

@author: Constanza
"""

import numpy as np

Mean_Percentile = np.zeros((155,5))

DataRt = np.loadtxt( "SS0_Rt_all100.csv", delimiter=",")

for day in range( 155 ):
    Data_day = DataRt[day,:]
    Valid_day =[]
    for x in Data_day:
        if x != 9999:
            Valid_day.append(x)
    Valid_day = np.array(Valid_day)
    Mean_Percentile[day][0] = day
    Mean_Percentile[day][1] = day + 11
    Mean_Percentile[day][2] = np.mean(Valid_day)
    Mean_Percentile[day][3] = np.percentile(Valid_day, 2.5)
    Mean_Percentile[day][4] = np.percentile(Valid_day, 97.5)

np.savetxt( "SS0_Rt_MeanPerc.csv",Mean_Percentile,delimiter=",",fmt="%s" )